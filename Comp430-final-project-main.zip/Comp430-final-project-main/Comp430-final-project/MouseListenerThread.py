import threading
from pynput import mouse

def mouse_moving(loc_x, loc_y):
    print("Mouse is moving, location is " + str(loc_x) + " " + str(loc_y))

def mouse_click(loc_x, loc_y, the_button, the_press):
    print("Mouse is clicked at location  :" + str(loc_x) + str(loc_y))
    print("The pressed button : " + str(the_button))
    if the_press:
        print("Right now it is pressed")
    else:
        print("Right now it is released")
def mouse_scrolled(loc_x, loc_y, x_2, y_2):
    print("Mouse is scrolled  at location:" + str(loc_x) + str(loc_y))
    print("The delta value is : " + str(x_2) + " -- " + str(y_2))


#start the mouse thread
mouse_listener = mouse.Listener(on_move=mouse_moving, on_click=mouse_click, on_scroll=mouse_scrolled).start
thread_for_mouse_listener = threading.Thread(target = mouse_listener)

def start_mouse_listener():
    thread_for_mouse_listener.start()
    while True:
        pass

start_mouse_listener()