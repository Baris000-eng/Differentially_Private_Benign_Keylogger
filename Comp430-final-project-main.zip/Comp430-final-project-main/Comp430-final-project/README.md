# Comp430-final-project
The missing keys project

to-do list
1.Keyboard listener --1 Jan -------------------------------------------Pending
2.Mouse Listener -- 1 Jan ---------------------------------------------Done 28 : December   
3.GUI - 2 screens -- 8 Jan --------------------------------------------Pending
4.Screenshot recorder (1 thread) -- 8 jan -----------------------------Pending
5.exponential mechanism, most used word -- 15 jan ---------------------Pending
6.visited sites list  -- 15 jan ---------------------------------------Pending
7.sending mail -- 22 jan   --------------------------------------------Pending

extra idead
1-mic listener
2-
