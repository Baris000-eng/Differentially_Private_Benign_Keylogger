import tkinter as tk

def create_main_screen():
    home_screen = tk.Tk()
    home_screen.title("Program Main Screen")
    home_screen.geometry("600x400")

    # Create the login button


    def start_the_keylogger():
        import MouseListenerThread as mouseT
        mouseT.start_mouse_listener()


    login_button = tk.Button(home_screen, text="Start the keylogger",command= start_the_keylogger(), bg="#00ff00")
    login_button.pack()


    # Create the sign up button
    signup_button = tk.Button(home_screen, text="Stop the keylogger", bg="#ff0000")
    signup_button.pack()


    home_screen.mainloop()

    # Show the window
    def show():
        home_screen.deiconify()
    
    # Hide the window
    def hide():
        home_screen.withdraw()

