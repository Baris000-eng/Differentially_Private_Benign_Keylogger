import threading # threading module importing
from pynput import mouse

def mouse_moving(loc_x, loc_y):
    print("Mouse is moving, location is " + str(loc_x) + " " + str(loc_y))

def mouse_click(loc_x, loc_y, the_button, the_press):
    print("Mouse is clicked at location  :" + str(loc_x) + str(loc_y))
    print("The pressed button : " + str(the_button))
    if the_press:
        print("Right now it is pressed")
    else:
        print("Right now it is released")
def mouse_scrolled(loc_x, loc_y, x_2, y_2):
    print("Mouse is scrolled  at location:" + str(loc_x) + str(loc_y))
    print("The delta value is : " + str(x_2) + " -- " + str(y_2))


#start the mouse thread
def start_mouse_listener():
    while True:
        mouse_listener = mouse.Listener(on_move=mouse_moving, on_click=mouse_click, on_scroll=mouse_scrolled)
        mouse_listener.start()







# # Set up logging
# log_dir = "" # Enter the log directory here
# logging.basicConfig(filename=(log_dir + "key_log.txt"), level=logging.DEBUG, format='%(asctime)s: %(message)s')

# # Set up keylogging
# def on_press(key):
#     logging.info(key)

# def on_release(key):
#     logging.info(key)

# # Collect events until stopped
# with pynput.keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
#     listener.join()
